response = {}

response["succeeded"] = True
response["result_msg"] = "Success: Nothing to test "